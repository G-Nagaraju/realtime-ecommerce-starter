require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const Product = require('./models/Product');
const Stripe = require('stripe');

const app = express();
const server = http.createServer(app);
const io = require('socket.io')(server, { cors: { origin: '*' } });

const stripe = Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_xxx');
const PORT = process.env.PORT || 4000;

app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());

mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/realtime_ecom', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected')).catch(err => console.error(err));

app.get('/api/products', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

app.get('/api/products/:id', async (req, res) => {
  const p = await Product.findById(req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

app.post('/api/create-checkout-session', async (req, res) => {
  const { items } = req.body;
  if (!items || !Array.isArray(items)) return res.status(400).json({ error: 'Invalid items' });

  const line_items = [];
  for (const it of items) {
    const prod = await Product.findById(it.id);
    if (!prod) return res.status(400).json({ error: 'Product not found' });
    line_items.push({
      price_data: {
        currency: 'usd',
        product_data: { name: prod.name, images: prod.image ? [prod.image] : [] },
        unit_amount: prod.price
      },
      quantity: it.quantity
    });
  }

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items,
    mode: 'payment',
    success_url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:5173'}/cart`
  });

  res.json({ url: session.url });
});

app.post('/api/order-complete', async (req, res) => {
  const { items } = req.body;
  for (const it of items) {
    const prod = await Product.findById(it.id);
    if (!prod) continue;
    prod.stock = Math.max(0, prod.stock - it.quantity);
    await prod.save();
    io.emit('stockUpdate', { id: prod._id, stock: prod.stock });
  }
  return res.json({ ok: true });
});

io.on('connection', socket => {
  console.log('Socket connected:', socket.id);
  socket.on('disconnect', () => console.log('Socket disconnected:', socket.id));
});

server.listen(PORT, () => console.log(`Server listening on ${PORT}`));
