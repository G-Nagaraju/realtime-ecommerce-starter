require('dotenv').config();
const mongoose = require('mongoose');
const Product = require('../models/Product');

async function seed(){
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/realtime_ecom', {
    useNewUrlParser: true, useUnifiedTopology: true
  });

  const items = [
    { name: 'Classic T-Shirt', description: '100% cotton tee', price: 1999, stock: 25, image: 'https://via.placeholder.com/200x200?text=T-Shirt' },
    { name: 'Running Shoes', description: 'Comfortable running shoes', price: 4999, stock: 10, image: 'https://via.placeholder.com/200x200?text=Shoes' },
    { name: 'Laptop Pro', description: 'Powerful laptop for work', price: 89999, stock: 5, image: 'https://via.placeholder.com/200x200?text=Laptop' }
  ];

  await Product.deleteMany({});
  await Product.insertMany(items);
  console.log('Seeded products');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
