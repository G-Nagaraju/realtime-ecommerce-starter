import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { io } from 'socket.io-client';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';

export default function App(){
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    fetchProducts();
    const socket = io(API);
    socket.on('stockUpdate', data => {
      setProducts(prev => prev.map(p => p._id === data.id ? { ...p, stock: data.stock } : p));
    });
    return () => socket.disconnect();
  }, []);

  async function fetchProducts(){
    const res = await axios.get(`${API}/api/products`);
    setProducts(res.data);
  }

  function addToCart(prod){
    setCart(c => {
      const exists = c.find(x => x.id === prod._id);
      if (exists) return c.map(x => x.id === prod._id ? { ...x, qty: x.qty+1 } : x);
      return [...c, { id: prod._id, name: prod.name, price: prod.price, qty: 1 }];
    });
  }

  async function checkout(){
    const items = cart.map(i => ({ id: i.id, quantity: i.qty }));
    const res = await axios.post(`${API}/api/create-checkout-session`, { items });
    window.location.href = res.data.url;
  }

  return (
    <div style={{ padding: 20, fontFamily: 'system-ui' }}>
      <h1>Realtime E‑commerce (Starter)</h1>
      <div style={{ display: 'flex', gap: 20 }}>
        <div style={{ flex: 1 }}>
          <h2>Products</h2>
          {products.map(p => (
            <div key={p._id} style={{ border: '1px solid #ddd', padding: 10, marginBottom: 8 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <strong>{p.name}</strong>
                  <div>{(p.price/100).toFixed(2)} USD</div>
                  <div>Stock: {p.stock}</div>
                </div>
                <div>
                  <button disabled={p.stock<=0} onClick={() => addToCart(p)}>Add</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ width: 320 }}>
          <h2>Cart</h2>
          {cart.length===0 && <div>Cart is empty</div>}
          {cart.map(item => (
            <div key={item.id} style={{ marginBottom: 8 }}>
              {item.name} x {item.qty} — ${(item.price*item.qty/100).toFixed(2)}
            </div>
          ))}
          <div style={{ marginTop: 12 }}>
            <button disabled={cart.length===0} onClick={checkout}>Checkout</button>
          </div>
        </div>
      </div>
    </div>
  );
}
