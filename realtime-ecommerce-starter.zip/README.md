# Realtime E‑Commerce Starter — React + Node/Express + MongoDB + Socket.IO + Stripe

This is a GitHub-ready starter repo with:
- frontend/ (React + Vite)
- backend/ (Node + Express + Mongoose + Socket.IO + Stripe)
- docker-compose.yml
- .env.example
- backend/scripts/seed.js (seed sample products)

## Quick deploy
1. Push this repo to GitHub.
2. Deploy backend to Render (or Railway) and set environment variables.
3. Deploy frontend to Vercel (or Netlify) and set VITE_API_URL to backend URL.
4. Run the seed script once to populate the DB (or use Render one-off job).

## One-click deploy buttons (edit <your-username> before use)
[![Deploy Frontend to Vercel](https://vercel.com/button)](https://vercel.com/import/project?template=https://github.com/<your-username>/realtime-ecommerce-starter)
[![Deploy Backend to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/<your-username>/realtime-ecommerce-starter)

## Local run (quick)
- Backend:
  ```
  cd backend
  npm install
  cp .env.example .env
  # edit .env if needed
  npm run dev
  ```
- Frontend:
  ```
  cd frontend
  npm install
  npm run dev
  ```
Open frontend at http://localhost:5173

## Stripe test keys included in .env.example (test mode)
- STRIPE_SECRET_KEY=sk_test_4eC39HqLyjWDarjtT1zdp7dc
- STRIPE_PUBLISHABLE_KEY=pk_test_TYooMQauvdEDq54NiTphI7jx

## Support
If you want, I can walk you through the Render/Vercel deploy steps or create GitHub Actions for automatic seeding.
